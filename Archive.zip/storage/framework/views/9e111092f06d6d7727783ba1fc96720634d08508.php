<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" >
    <head>
        <meta charset="utf-8">
        <title>LTC GROUP VISA</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="LTC Group VISA UBA" name="description">
        <meta content="Vente et recharge des cartes prépayée visa UBA" name="keywords">
        <!-- Favicons -->
        <link href="<?php echo e(asset('imports/img/favicon.ico')); ?>" rel="icon">
        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700;800&family=Rubik:wght@400;500;600;700&display=swap" rel="stylesheet">
        <!-- Icon Font Stylesheet -->
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">
        <!-- Libraries Stylesheet -->
        <link href="<?php echo e(asset('imports/lib/owlcarousel/assets/owl.carousel.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('imports/lib/animate/animate.min.css')); ?>" rel="stylesheet">
        <!-- Customized Bootstrap Stylesheet -->
        <link href="<?php echo e(asset('imports/css/bootstrap.min.css')); ?>" rel="stylesheet">
        <!-- Template Stylesheet -->
        <link href="<?php echo e(asset('imports/css/style.css')); ?>" rel="stylesheet">
    </head>
    <body>

        <?php echo $__env->make('partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- Vendor JS Files -->
        <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('imports/lib/wow/wow.min.js')); ?>"></script>
        <script src="<?php echo e(asset('imports/lib/easing/easing.min.js')); ?>"></script>
        <script src="<?php echo e(asset('imports/lib/waypoints/waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('imports/lib/counterup/counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('imports/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
        <!-- Template Main JS File -->
        <script src="<?php echo e(asset('imports/js/main.js')); ?>"></script>
            
    </body>
</html><?php /**PATH /Users/hardpro/ubaCard/resources/views/layouts/app.blade.php ENDPATH**/ ?>